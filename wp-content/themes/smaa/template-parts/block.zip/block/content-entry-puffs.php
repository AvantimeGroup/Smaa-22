<section class="entry-puffs" >
    <div class="container">
    <h1 class="text-center "><?php the_field('title'); ?></h1> 
        <div class="row">
            <div class="col container-puffs ">
                <div class="column-25 puff">
                    <div class="circle-127px"><i><?php the_field('puff_ikon_1'); ?></i></div>
                    <p class="puff-text"><?php the_field('puff_text_1'); ?>  </p>
                    <a href="<?php the_field('puff_link_1'); ?>" class="puff-link">Läs mer <i class="fa fa-angle-right"></i></a>
                </div>
                <div class="column-25 puff">
                    <div class="circle-127px"><i><?php the_field('puff_ikon_2'); ?></i></div>   
                    <p class="puff-text"><?php the_field('puff_text_2'); ?>   </p>
                    <a href="<?php the_field('puff_link_2'); ?>" class="puff-link">Läs mer <i class="fa fa-angle-right"></i></a>
                </div>
                <div class="column-25 puff">
                    <div class="circle-127px"><i><?php the_field('puff_ikon_3'); ?></i></div> 
                    <p class="puff-text"><?php the_field('puff_text_3'); ?>   </p>
                    <a href="<?php the_field('puff_link_3'); ?>" class="puff-link">Läs mer <i class="fa fa-angle-right"></i></a>  
                </div>
                <div class="column-25 puff">
                    <div class="circle-127px"><i><?php the_field('puff_ikon_4'); ?></i></div> 
                    <p class="puff-text"><?php the_field('puff_text_4'); ?>   </p>
                    <a href="<?php the_field('puff_link_4'); ?>" class="puff-link">Läs mer <i class="fa fa-angle-right"></i></a>  
                </div>   
            </div>
        </div>
    </div>
</section>