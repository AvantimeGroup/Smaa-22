<section class="smaa-block alert-block block-bg-white d-none">
    <div class="alert" role="alert">
        <div class="container">
            <div class="text-shell">
                <h5><i class="fa fa-exclamation-circle" aria-hidden="true"></i></h5>
                <?php the_field('text'); ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true"></span>
                </button>
            </div>
        </div>
    </div>
</section>