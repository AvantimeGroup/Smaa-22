<?php 
/**
 *  Block Template: sidebar menu
 *
 */
 if( get_field('menu_title') ){
    $menu_title = get_field('menu_title'); 
    }
?>
<script>
    jQuery(document).ready(function () {
        jQuery("#sticker").stick_in_parent({
            offset_top: 150
        });
        jQuery('.sticky-wrapper .wp-block-column.sticky-main section').hide();
        jQuery('.sticky-wrapper .wp-block-column.sticky-main section').first().fadeIn();
        jQuery('#sidenav-wrapper a ').click(function(){    
            var get = jQuery(this).attr('href');
             jQuery('.sticky-wrapper .wp-block-column.sticky-main section').hide(500);
             jQuery('.sticky-wrapper .wp-block-column section' + get).fadeIn(500);
        });
    });
</script>


<section class="sidebar-menu" id="sticker">
    <div id="#sidenav" class="col-md-324 ">
        <nav class="sidenav sticky-sidebar" >
            <div class="sticky-title"><?php echo $menu_title; ?></div>

            <div id="sidenav-wrapper" class="">
                <ul class="sidenav-menu">
                <?php 
                if( get_field('sticky_meny_slug') ){
                    $menu_slug = get_field('sticky_meny_slug'); 
                    do_shortcode('[addmenu name="'.  $menu_slug  .'"]'); 
                }
                ?>
                </ul>       
            </div>
        </nav>
    </div>
</section>