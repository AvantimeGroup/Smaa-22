
 <?php 
    if( get_field('link_btn_color') == 'white' ) {
        $class_link_btn = 'btn-white';
    
    } else {
        $class_link_btn = 'orange';

    }
    if( get_field('button_color') == 'black' ) {
        $class_btn = 'btn-black';
      
    } else {
        $class_btn = 'orange-file';

    }
 ?>
<section class=" cta-text-file-download" >
    <div class="container">
        <div class="row">
            <div class="col ">
                <h1 class="text-center "><?php the_field('title'); ?></h1>
                <p><?php the_field('bread_text'); ?></p>
                <div class="block-buttons ">

                <?php   if( get_field('link_btn_text')): ?> <!--  url link -->
                    <div class="block-button">
                        <a href="<?php the_field('link_url'); ?>"  class="<?php echo $class_link_btn; ?>" >     
                            <?php the_field('link_btn_text'); ?><?php the_field('link_btn_icon'); ?>
                        </a>
                    </div>
                <?php  endif; ?> 
                
                <?php   if( get_field('file_url')): ?> <!-- file download link -->
                    <div class="block-button">
                        <a class=" <?php echo $class_btn; ?> has-background" href="<?php the_field('file_url'); ?>"><?php the_field('btn_text'); ?> <?php the_field('btn_icon'); ?></a>
                    </div>
                </div>
                <?php  endif; ?>  

                </div>           
            </div>
        </div>
    </div>
</section>