<section class="smaa-block-breadcrumbs" >
    <div class="container">
        <div class="breadcrumb-row">
        <?php
            if (function_exists('yoast_breadcrumb')) {
                yoast_breadcrumb('<p id="breadcrumbs">', '</p>');
            }
        ?>
        </div>
    </div>
</section>