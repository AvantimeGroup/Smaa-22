<?php
/**
 * Block Name: Hero Divider Gray curve.
 *
 * This is the template for hero blocks.
 */


?>

 <section class=" hero-divider-curve ">
    <div class="curve-bottom">
        
    </div>
</section>