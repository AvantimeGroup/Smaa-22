<section class="block-sixty-fourty-text-left">
    <div class="container wrapper-60-40">
        <div class="column-60">
            <h1 class="text-left "><?php the_field('title'); ?></h1>
            <div class="left-bread">
                <?php the_field('paragraph_1'); ?>
            </div>  
         </div>

        <div class="column-40">
            <div class="decoration-1">
                <div class="orange-ring-42px"></div>
            </div>
            <div class="decoration-2">
                <div class="blue-ring-72px"></div>
            </div>         
        </div>
    </div>
</section>