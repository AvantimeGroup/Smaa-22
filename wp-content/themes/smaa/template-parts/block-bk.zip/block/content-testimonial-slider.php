<?php

/**
 * Slider Block Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */

// Create id attribute allowing for custom "anchor" value.
$id = 'slider-' . $block['id'];
if( !empty($block['anchor']) ) {
    $id = $block['anchor'];
}

// Create class attribute allowing for custom "className" and "align" values.
$className = 'slider';
if( !empty($block['className']) ) {
    $className .= ' ' . $block['className'];
}
if( !empty($block['align']) ) {
    $className .= ' align' . $block['align'];
}


?>


<div class="testimonial-slider">
	<div class="container ">
	<div class="decoration-left"><div class="blue-ring-50px"></div></div>			
        <div class="slider">
		
        <?php if (have_rows('testimonial_slider')): ?>
            <div class="slick-container">

            <?php while (have_rows('testimonial_slider')): the_row(); ?>
              	<div class="t-slide">
					<div class="slide-box">

						<!-- <div class="column-40">   -->
							<div class="slider-img">
								<?php if(get_sub_field('slide_image' )): ?>
									<img src="<?php the_sub_field('slide_image'); ?>" />
								<?php endif; ?>
							</div>					
						<!-- </div> -->

						<!-- <div class="column-60"> -->
							<h1 class="title-right "><?php the_sub_field('slide_title'); ?></h1>

							<blockquote>
								<cite>
									<?= the_sub_field('slide_quote'); ?>
								</cite>
							</blockquote>

							<div class="bread-right">
								<?php the_sub_field('slide_bio'); ?>
							</div> 

							<?php if( get_sub_field('slide_btn') ): ?>
								<div class="link-right">
									<?php 
										$btnLink =	get_sub_field('slide_btn'); 
									?>
									<p class=" text-left"><a class="btn btn-primary slider-btn" href="<?php echo esc_url( $btnLink['url'] ); ?>"><?php echo esc_attr( $btnLink['title']); ?></a></p>
								</div>
                            <?php endif; ?>
						<!-- </div> -->
					</div>
				</div>

            <?php endwhile; ?>

           	</div>

			<div class="slider-nav">	    
				<div class="prev"><i class="fa fa-angle-left fa-2x" aria-hidden="true"></i></div>
				<div class="nav-dots"> </div>
				<div class="next"><i class="fa fa-angle-right fa-2x" aria-hidden="true"></i></div>
			</div>
         <?php endif; ?>
      </div>
	  	  <div class="decoration-right"><div class="light-blue-ring-25px"></div></div>
	  <div class="decoration-right-right"><div class="blue-ring-38px"></div></div>
	</div>
</div>
<script type="text/javascript">
/*      jQuery(document).ready(function($){

		$('.slick-container').each(function() {
			var slickInstance = $(this);
			// $('.slick-container').slick({
			$(this).slick({
				speed: 300,
				autoplay:false,
				dots: true,
				slidesToShow:1,
				slidesToScroll:1,
				// appendDots: '.nav-dots',
				appendDots: slickInstance.next().find('.nav-dots'),
				// appendDots:   $('.slick-container__nav-dots',   this),
				nextArrow: slickInstance.next().find('.next'),
				prevArrow: slickInstance.next().find('.prev')

				// nextArrow: $('.next'),
				// prevArrow: $('.prev')
			})

		});
    });  */
</script>